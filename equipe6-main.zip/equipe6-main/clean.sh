#!/bin/bash
rm -r .vagrant
rm -rf logs/*
