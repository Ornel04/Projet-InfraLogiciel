<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="utf-8">
	<link href="./css/bootstrap.min.css" rel="stylesheet">
	<link href="./css/style.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">  
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<style>
		@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&display=swap');
	</style>
	<script src="https://kit.fontawesome.com/f95cfba783.js" crossorigin="anonymous"></script>
	<title><?php echo $_TITRE_PAGE; ?></title>
</head>

<body>
	<!-- HEADER -->
	<header class="header">
        <div class="col">
            <div class="gap-2 nav-bar-header">
                <a href="" class="btn btn-sm button-header" style="text-transform: none;" tabindex="-1" role="button" aria-disabled="true">Numéro d'urgence</a>
                <a href="" class="btn btn-sm button-header" style="text-transform: none;" tabindex="-1" role="button" aria-disabled="true">Se repérer au CHU</a>
                <?php if (!empty($_SESSION['compte'])) { ?>
                    <a href="./mon_compte.php" class="btn btn-sm button-header float-right" style="text-transform: none;" role="button">Mon compte</a>
                <?php } else { ?>
                    <a href="./connexion_inscription.php" class="btn btn-sm button-header float-right" style="text-transform: none;" role="button">Se connecter / Inscription</a>
                <?php } ?>
				<a href="http://192.168.4.135/index.php?logout=1" class="btn btn-sm button-header float-right" role="button"><i class="fa-solid fa-right-to-bracket"></i></a>
                
                
            </div>

            <div class="row header-container" style="background-image: url('./medias/eseo_background.png');">
                <div class="col-header-logo">
                    <a class="header-logo" href="./index.php">
                        <img width="150px "src="./medias/logo_CHU_ESEO_ANGERS.png" class="img-fluid"/>
                    </a>
                </div>
            </div>
        </div>
    </header>

