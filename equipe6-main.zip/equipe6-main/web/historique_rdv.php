<?php
    include './core/core.php';
    $_TITRE_PAGE = 'Historique RDV';


    //Demande de connexion si non connecté
    if(empty($_SESSION['compte'])){
        header('Location: ./connexion_inscription.php');
    }

    include('./header_all.php');
?>

<main>
        <div class="row">
            <div class="col-lg-3 col-mg-12">
                <div class="col-nav-menu">
                    <h3>Menu de navigation</h3>
                    <br>
                    <a href="./index.php"> > Accueil</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './mon_compte.php'; ?>"> > Mon compte</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './prendre_rdv.php'; ?>"> > Prendre rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './gestion_rdv.php'; ?>"> > Gérer mes rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './historique_rdv.php'; ?>"> > Historique des rendez-vous</a>
                </div>
            </div>
            <div class="col-lg-9 col-mg-12">
                <div class="col-main-section-general">
                                    
                    <div class="main-section-general" style="margin-bottom: 20px;">
                        <h2>Rendez-vous en cours</h2>
                        <hr/>

                        <?php 
                        $sql = "SELECT * FROM RDV WHERE idUtilisateur = '" . $_SESSION['compte'] . "'";
                        $result = $mysqli->query($sql);

                        if (!$result) {     exit($mysqli->error);   }
                        $nb = $result->num_rows;
                        if ($nb) {    
                            while($row = $result->fetch_assoc();){
                        ?>
                                <div class="card">
                                    <div class="card-header">
                                        Rendez-vous - <?php echo $row['nom']; ?> N°<?php echo $row['id']; ?>
                                    </div>
                                    <div class="card-body" id="<?php echo 'card-' . $row['id'] ?>">
                                        <!--<h5 class="card-title">Special title treatment</h5>--->
                                        <?php 
                                        $sql_date = "SELECT DATE(debut) as jour, TIME(debut) as debut, TIME(fin) as fin FROM RDV WHERE id = '" . $row['id'] . "'";
                                        $result_date = $mysqli->query($sql_date);
                                        if (!$result_date) {     exit($mysqli->error);   }
                                        $date = $result->fetch_assoc();
                                        ?>
                                        <p class="card-text">Date : <?php echo $date['jour']; ?></p>
                                        <p class="card-text">Heure de début : <?php echo $date['debut']; ?></p>
                                        <p class="card-text">Heure de fin : <?php echo $date['fin']; ?></p>
                                    </div>
                                </div>
                                <?php
                                }
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <?php
    include('./footer_all.php');
?>









