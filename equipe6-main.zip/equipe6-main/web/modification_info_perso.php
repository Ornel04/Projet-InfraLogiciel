<?php  
    include('./core/core.php');
    
    
    $_TITRE_PAGE = 'Informations personnelles';


    //Demande de connexion si non connecté
    if(empty($_SESSION['compte'])){
        header('Location: ./connexion_inscription.php');
        exit;
    }


    //Récupération des information de l'utilisateur
    $sql = "SELECT	id, nom, prenom, date_de_naissance, numero_mobile, adresse, email, idGenre, mot_de_passe
            FROM	Utilisateur WHERE id = '" . $_SESSION['compte'] . "'";

    $result = $mysqli->query($sql);

    if (!$result) {     exit($mysqli->error);   }
    $nb = $result->num_rows;
    if ($nb) {      $row = $result->fetch_assoc();   }


    //Récupération info sexe utilisateur
    $sql2 = "SELECT	* FROM	Genre WHERE	id = '" . $row['idGenre'] . "'";
    
    $result_genre = $mysqli->query($sql);

    if (!$result_genre) {   exit($mysqli->error);   }
    $nb2 = $result_genre->num_rows;
    if ($nb2) {     $row_genre = $result_genre->fetch_assoc();   }



    //Gestion modification form
    if (isset($_POST['modif_submit']) && $_POST['modif_submit'] == 1) {

        if(!empty($_POST['nom']) && $_POST['nom'] != $row['nom']) {
            $sql_nom = "UPDATE Utilisateur SET nom = '".$_POST['nom']."' WHERE id = '".$_SESSION['compte']."'";
            $result_nom = $mysqli->query($sql_nom);
            if (!$result_nom) { exit($mysqli->error); }
        }

        if(!empty($_POST['prenom']) && $_POST['prenom'] != $row['prenom']) {
            $sql_prenom = "UPDATE Utilisateur SET prenom = '".$_POST['prenom']."' WHERE id = '".$_SESSION['compte']."'";
            $result_prenom = $mysqli->query($sql_prenom);
            if (!$result_prenom) { exit($mysqli->error); }
        }

        if(!empty($_POST['date_de_naissance']) && $_POST['date_de_naissance'] != $row['date_de_naissance']) {
            $sql_date_de_naissance = "UPDATE Utilisateur SET date_de_naissance = '".$_POST['date_de_naissance']."' WHERE id = '".$_SESSION['compte']."'";
            $result_date_de_naissance = $mysqli->query($sql_date_de_naissance);
            if (!$result_date_de_naissance) { exit($mysqli->error); }
        }

        if(!empty($_POST['adresse']) && $_POST['adresse'] != $row['adresse']) {
            $sql_adresse = "UPDATE Utilisateur SET adresse = '".$_POST['adresse']."' WHERE id = '".$_SESSION['compte']."'";
            $result_adresse = $mysqli->query($sql_adresse);
            if (!$result_adresse) { exit($mysqli->error); }
        }

        if(!empty($_POST['numero_mobile']) && $_POST['numero_mobile'] != $row['numero_mobile']) {
            $sql_numero_mobile = "UPDATE Utilisateur SET numero_mobile = '".$_POST['numero_mobile']."' WHERE id = '".$_SESSION['compte']."'";
            $result_numero_mobile = $mysqli->query($sql_numero_mobile);
            if (!$result_numero_mobile) { exit($mysqli->error); }
        }

        if(!empty($_POST['email']) && $_POST['email'] != $row['email']) {
            $sql_email = "UPDATE Utilisateur SET email = '".$_POST['email']."' WHERE id = '".$_SESSION['compte']."'";
            $result_email = $mysqli->query($sql_email);
            if (!$result_email) { exit($mysqli->error); }
        }

        if(!empty($_POST['sexe']) && $_POST['sexe'] != $row['idGenre']) {
            $sql_sexe = "UPDATE Utilisateur SET idGenre = '".$_POST['sexe']."' WHERE id = '".$_SESSION['compte']."'";
            $result_sexe = $mysqli->query($sql_sexe);
            if (!$result_sexe) { exit($mysqli->error); }
        }


    }

    if (isset($_POST['modif_password_submit']) && $_POST['modif_password_submit'] == 2) {

        if(!empty($_POST['mot_de_passe']) && !empty($_POST['conf_mot_de_passe'])) {
            if($_POST['mot_de_passe'] != $row['mot_de_passe']){  //A modifier si ont utilise le hash
                if($_POST['mot_de_passe'] == $_POST['conf_mot_de_passe']){
                    $sql_mot_de_passe = "UPDATE Utilisateur SET mot_de_passe = '".$_POST['mot_de_passe']."' WHERE id = '".$_SESSION['compte']."'";
                    $result_mot_de_passe = $mysqli->query($sql_mot_de_passe);
                    if (!$result_mot_de_passe) { exit($mysqli->error); }
                }
            }
        }
    }

    
    include('./header_all.php');

?>


<main>
        <div class="row">
            <div class="col-lg-3 col-mg-12">
                <div class="col-nav-menu">
                    <h3>Menu de navigation</h3>
                    <br>
                    <a href="./index.php"> > Accueil</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './mon_compte.php'; ?>"> > Mon compte</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './prendre_rdv.php'; ?>"> > Prendre rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './gestion_rdv.php'; ?>"> > Gérer mes rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './historique_rdv.php'; ?>"> > Historique des rendez-vous</a>
                </div>
            </div>
            <div class="col-lg-9 col-mg-12">
                <div class="col-main-section-general">
                    <form method="post" name="modif_info" class="form-section-general">                    
                        <div class="main-section-general">
                            <h2>Modification information générale</h2>
                            <hr/>
                            <p class=" mb-0">
                                <label for="nom">Nom</label>
                                <input class="form-control mb-4" type="text" id="nom" name="nom" value="<?php echo $row['nom']?>">
                            </p>
                            <p class=" mb-0">
                                <label for="prenom">Prénom</label>
                                <input class="form-control mb-4" type="text" id="prenom" name="prenom" value="<?php echo $row['prenom']?>">
                            </p>
                            <p class=" mb-0">
								<label for="sexe" class="active">Sexe</label>
								<select name="sexe" id="sexe" class="form-control mb-4">
                                    <option value="<?php echo $row_genre->id ?>" selected><?php echo $row_genre->nom ?></option>
				    				<?php
									$query_as = $mysqli->query("SELECT * FROM Genre ORDER BY id ASC");
									while ($sexe = $query_as->fetch_object()) {
									?>
										<option value="<?php echo $sexe->id ?>"><?php echo $sexe->nom ?></option>
									<?php
									}
									?>
								</select>
							</p>
                            <p class=" mb-0">
                                <label for="date_de_naissance">Date de naissance</label>
                                <input class="form-control mb-4" type="date" id="date_de_naissance" name="date_de_naissance" value="<?php echo $row['date_de_naissance']?>">
                            </p>
                        </div>
                        <hr/>
                        <div class="main-section-general">
                            <h2>Contact</h2>
                            <hr/>
                            <p class=" mb-0">
                                <label for="numero_mobile">Numero mobile</label>
                                <input class="form-control mb-4" type="text" id="numero_mobile" name="numero_mobile" value="<?php echo $row['numero_mobile']?>">
                            </p>
                            <p class=" mb-0">
                                <label for="adresse">Email</label>
                                <input class="form-control mb-4" type="text" id="email" name="email" value="<?php echo $row['email']?>">
                            </p>
                            <p class=" mb-0">
                                <label for="adresse">Adresse</label>
                                <input class="form-control mb-4" type="text" id="adresse" name="adresse" value="<?php echo $row['adresse']?>">
                            </p>
                        </div>
                        <hr/>
                        <div class="d-grid gap-2 col-6 mx-auto" style="margin-bottom: 20px;">
                            <button name="modif_submit" class="btn btn-mdb-color btn-block mt-4 mb-0" type="submit" value="1">Valider modification</button>
                        </div>
                    </form>
                    <form method="post" name="modif_info"  class="form-section-general">                    
                        <div class="main-section-general">
                            <h2>Modification mot de passe</h2>
                            <hr/>
                            <p class=" mb-0">
                                <label for="mot_de_passe">Nouveau mot de passe</label>
                                <input class="form-control mb-4" type="password" id="mot_de_passe" name="mot_de_passe" value="">
                            </p>
                            <p class=" mb-0">
                                <label for="conf_mot_de_passe">Confirmation mot de passe</label>
                                <input class="form-control mb-4" type="text" id="conf_mot_de_passe" name="conf_mot_de_passe" value="">
                            </p>
                        </div>
                        <hr/>
                        <div class="d-grid gap-2 col-6 mx-auto" style="margin-bottom: 20px;">
                            <button name="modif_password_submit" class="btn btn-mdb-color btn-block mt-4 mb-0" type="submit" value="2">Valider modification mot de passe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>


    <?php
    include('./footer_all.php');
?>









