<?php

//Affichage des erreurs
//TODO revoir si il faux bien afficher toutes les erreurs
error_reporting(E_ALL);
ini_set('display_errors', 'On');
ini_set('display_startup_errors', 'On');

//Permet de démarer une session utilisateur, permet de stocker les 
// infos de l'utilisateur pour que le serveur se souvienne de lui
//et qu'il puisse rester connecté
session_start();

//Structure pour stocker les informations de connexion à la base de données
$infoBdd = ['server' => '192.168.56.80', 
            'login' => 'icare',
            'password' => '1c4r3',
            'db_name' => 'BasDonner' ];

//connexion à la basse de donées
$mysqli = new mysqli($infoBdd['server'], $infoBdd['login'], $infoBdd['password'], $infoBdd['db_name']);
//gestion des problemes de connexion à la basse de données
if($mysqli->connect_errno) {
    exit('Problème de connexion à la BDD');
}

//Permet la deconnexion si le lien est cliqué
if(isset($_GET['logout']) && $_GET['logout'] == 1) {
    unset($_SESSION['compte']);
    header("Location: ./index.php"); 
}

?>