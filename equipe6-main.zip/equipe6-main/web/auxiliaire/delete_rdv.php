<?php 
    include("../core/core.php");

    if(!empty($_POST["id_rdv"] )){
        $sql = "DELETE FROM RDV WHERE id = '" . $_POST["id_rdv"] . "'";
        $result = $mysqli->query($sql);
        if (!$result) {
            exit($mysqli->error);
        }
    }
?>