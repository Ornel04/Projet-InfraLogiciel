<?php
include("../core/core.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Recherche du nom de la salle
    $sql_spe = "SELECT * FROM Specialite WHERE id = '" . $idPersonnel . "'";

    if($result_spe = $mysqli->query($sql_spe)){
        $row_specialisation = $result_spe->fetch_assoc();

        // Récupération des paramètres envoyés par AJAX
        $debut = $_POST['debut'];
        $nomRDV = "Rendez-vous '" . $row_specialisation['nom'] . "' du '" . $debut . "'";
        $fin = $_POST['fin'];
        $confirmatoion = $_POST['confirmation'];
        $idSalle = $_POST['idSalle'];
        $idPersonnel = $_POST['idPersonnel'];
        $userId = $_POST['userId'];

        // Préparation de la requête SQL
        $sqlInsertRDV = "INSERT INTO RDV (nom, debut, fin, confirmation, idUtilisateur, idSalle, idPersonnel)
                        VALUES (?, ?, ?, ?, ?, ?, ?)";

        // Préparation et exécution de la requête
        if ($stmt = $mysqli->prepare($sqlInsertRDV)) {
            // Lier les paramètres de la requête préparée
            $stmt->bind_param("ssssiii", $nomRDV, $debut, $fin, $confirmation, $userId, $idSalle, $idPersonnel);

            // Exécution de la requête
            if ($stmt->execute()) {
                $sql_salle = "SELECT * FROM Salle WHERE id = '" . $idSalle . "'";
                if($result_salle = $mysqli->query($sql_salle)){
                    $row_salle = $result_salle->fetch_assoc();
                    
                    // Générer la réponse HTML avec les informations du RDV
                    echo "<p>Vous avez sélectionné :</p>
                        <div class='card-body'>
                            <h5 class='card-title'>Information du rendez-vous choisi</h5>
                            <p class='card-text'><strong>Nom :</strong> " . htmlspecialchars($nomRDV) . "</p>
                            <p class='card-text'><strong>Spécialité :</strong> " . $row_specialisation['nom'] . "</p>
                            <p class='card-text'><strong>Salle :</strong> " . $row_salle['nom']  . "</p>
                            <p class='card-text'><strong>Date :</strong> " . htmlspecialchars($debut->format('d/m/Y')) . "</p>
                            <p class='card-text'><strong>Heure de début :</strong> " . htmlspecialchars($debut->format('H:i')) . "</p>
                            <p class='card-text'><strong>Heure de fin :</strong> " . htmlspecialchars($fin->format('H:i')) . "</p>
                        </div>";
                }
                
            } else {
                echo "Erreur lors de la sauvegarde du rendez-vous";
            }

            // Fermeture de la requête
            $stmt->close();
        } else {
            echo "Erreur dans la préparation de la requête.";
        }
    
    } else {
        echo "Erreur lors de l'enregistrement des données";
    }

?>