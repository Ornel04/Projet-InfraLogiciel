<?php

    include('../core/core.php');

    // Vérifie si une requête POST a été envoyée
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Récupération de l'option sélectionnée par l'utilisateur
        $selectedOption = isset($_POST['selectedOption']) ? intval($_POST['selectedOption']) : null;

        // Vérification que l'option a bien été envoyée
        if ($selectedOption === null) {
            echo "<tr><td colspan='3'>Erreur : Aucune spécialité sélectionnée.</td></tr>";
            exit;
        }

        // Requête SQL pour récupérer les disponibilités basées sur l'option choisie
        $sql = "SELECT d.debut, d.fin, d.idPersonnel
                FROM Disponibilite d
                JOIN SpecialitePersonnel sp ON sp.idPersonnel = d.idPersonnel
                WHERE sp.idSpecialite = '" . $_POST["selectedOption"] . "' AND NOT EXISTS (
                    SELECT 1 FROM RDV r
                    WHERE r.idPersonnel = d.idPersonnel AND (
                        (r.debut <= d.debut AND r.fin > d.debut) OR
                        (r.debut < d.fin AND r.fin >= d.fin) OR
                        (r.debut >= d.debut AND r.fin <= d.fin) OR
                        (d.debut < r.fin AND d.fin >= r.debut)
                    )
                )
                ORDER BY d.debut ASC
            ";

        // Execution de la requête
        if ($result = $mysqli->query($sql)) {          

            // Vérifie si des horaires sont disponibles
            if ($result->num_rows > 0) {
                // Boucle sur chaque résultat et génère les lignes du tableau
                while ($row = $result->fetch_assoc()) {
                    $startTime = new DateTime($row['debut']);
                    $endTime = new DateTime($row['fin']);

                     // Génération des créneaux d'une heure
                    while ($startTime < $endTime) {
                        $slotStart = clone $startTime;
                        $slotEnd = (clone $startTime)->add(new DateInterval('PT1H')); // Ajoute 1h

                        // Si le créneau dépasse la plage de disponibilité, on arrête
                        if ($slotEnd > $endTime) {
                            break;
                        }

                        if (in_array($slotStart->format('i'), ['00', '15', '30', '45'])) {
                            echo "<tr onclick='selectRow(this)'>";
                            echo "<td>" . htmlspecialchars($slotStart->format('d/m/Y')) . "</td>";
                            echo "<td>" . htmlspecialchars($slotStart->format('H:i')) . "</td>";
                            echo "<td>" . htmlspecialchars($slotEnd->format('H:i')) . "</td>";
                            echo "</tr>";
                        }

                        // Incrémente le début pour passer au créneau suivant
                        $startTime->add(new DateInterval('PT15M')); // Ajoute 15 minutes
                

                    }
                
                }
            } else {
                // Aucun horaire disponible pour cette spécialité
                echo "<tr><td colspan='3'>Aucun horaire disponible pour cette spécialité.</td></tr>";
            }

        } else {
            // Erreur lors de la préparation de la requête SQL
            echo "<tr><td colspan='3'>Erreur lors de la récupération des horaires.</td></tr>";
        }
    } else {
        // Accès interdit si la requête n'est pas en POST
        echo "<tr><td colspan='3'>Accès non autorisé.</td></tr>";
    }
?>