<?php 
    include("../core/core.php");

    if(!empty($_POST["debut"]) && !empty($_POST["selectedOption"])){

        $sql ="SELECT d.idPersonnel, s.id AS idSalle
            FROM Disponibilite d
            JOIN SpecialitePersonnel sp ON sp.idPersonnel = d.idPersonnel
            JOIN SpecialiteSalle ss ON ss.idSpecialite = sp.idSpecialite
            JOIN Salle s ON s.id = ss.idSalle
            WHERE sp.idSpecialite = '" . $_POST["selectedOption"] . "' AND d.debut <= '" . $_POST["debut"] . "' AND NOT EXISTS (
                SELECT 1 FROM RDV r
                WHERE r.idPersonnel = d.idPersonnel AND (
                    (r.debut <= d.debut AND r.fin > d.debut) OR
                    (r.debut < d.fin AND r.fin >= d.fin) OR
                    (r.debut >= d.debut AND r.fin <= d.fin) OR
                    (d.debut < r.fin AND d.fin >= r.debut)
                )
            )
            LIMIT 1
    ";

        $result = $mysqli->query($sql);
        if (!$result) {
            exit($mysqli->error);
            
        } else {
            $row = $result->fetch_assoc();
            echo json_encode($row);
        }
    }
 ?>

                    