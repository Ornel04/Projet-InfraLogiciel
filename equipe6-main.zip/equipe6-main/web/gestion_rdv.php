<?php
    include('./core/core.php');
    $_TITRE_PAGE = 'Gestion RDV';


    //Demande de connexion si non connecté
    if(empty($_SESSION['compte'])){
        header('Location: ./connexion_inscription.php');
    }

    include('./header_all.php');
?>


<main>
        <div class="row">
            <div class="col-lg-3 col-mg-12">
                <div class="col-nav-menu">
                    <h3>Menu de navigation</h3>
                    <br>
                    <a href="./index.php"> > Accueil</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './mon_compte.php'; ?>"> > Mon compte</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './prendre_rdv.php'; ?>"> > Prendre rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './gestion_rdv.php'; ?>"> > Gérer mes rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './historique_rdv.php'; ?>"> > Historique des rendez-vous</a>
                </div>
            </div>
            <div class="col-lg-9 col-mg-12">
                <div class="col-main-section-general">
                                    
                    <div class="main-section-general" style="margin-bottom: 20px;">
                        <h2>Rendez-vous en cours</h2>
                        <hr/>

                        <?php 
                        $sql = "SELECT * FROM RDV r WHERE r.idUtilisateur = '" . $_SESSION['compte'] . "' AND r.debut > NOW()";
                        $result = $mysqli->query($sql);

                        if (!$result) {     exit($mysqli->error);   }
                        $nb = $result->num_rows;
                        if ($result && $nb >0) {    
                            while($row = $result->fetch_assoc()){ ?>
                                <div class="card">
                                    <div class="card-header">
                                        Rendez-vous - <?php echo $row['nom']; ?> N°<?php echo $row['id']; ?>
                                    </div>
                                    <div class="card-body" id="<?php echo 'card-' . $row['id']; ?>">
                                        <!--<h5 class="card-title">Special title treatment</h5>--->
                                        <?php 
                                        $sql_date = "SELECT DATE(debut) as jour, TIME(debut) as debut, TIME(fin) as fin FROM RDV WHERE id = '" . $row['id'] . "'";
                                        $result_date = $mysqli->query($sql_date);
                                        if (!$result_date) {     exit($mysqli->error);   }
                                        $date = $result->fetch_assoc();
                                        ?>
                                        <p class="card-text">Date : <?php echo $date['jour']; ?></p>
                                        <p class="card-text">Heure de début : <?php echo $date['debut']; ?></p>
                                        <p class="card-text">Heure de fin : <?php echo $date['fin']; ?></p>
                                    </div>
                                    <div class="card-footer text-body-secondary">
                                        <button name ="delete_rdv" onclick="delete_rdv(<?php echo $row['id']; ?>, 'card-<?php echo $row['id']; ?>')" class="btn btn-mdb-color btn-block mt-4 mb-0" id="delete_rdv" type="button" value="<?php echo $row['id'] ?>">Annuler le rendez-vous</button>
                                    </div>

                                    <script>
                                        function delete_rdv(id_rdv, cardid) {
                                            const xhttp = new XMLHttpRequest();
                                            xhttp.onreadystatechange = function() {  //pas de param   
                                                if (this.readyState == 4 && this.status == 200) {
                                                    document.getElementById(cardid).remove();
                                                }
                                            }
                                            xhttp.open("POST", "./auxiliaire/delete_rdv.php", true);
                                            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                            xhttp.send("id_rdv=" + id_rdv);
                                        }
                                    </script>
                                </div>
                            <?php }
                        } else {
                            echo "<p>Aucun rendez-vous en cours.</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <?php
    include('./footer_all.php');
?>









