    <footer>
        <div class="row footer-bandeau">
            <div class="col-lg-3 col-md-12 col-footer-logo"> 
                <div class="row footer-logo" >
                    <a href="/index.php" class="banniere-logo" title="Retour à la page d'acceuil">
                        <img src="./medias/logo_CHU_ESEO_ANGERS.png" class="img-fluid" alt="logo_CHU_ESEO_ANGERS" title="Retour à la page d'acceuil">                
                    </a>
                 </div>
            </div>        
            <div class="col-lg-3 col-md-12"> 
                <span class="menu-title">Press</span>
                <div class="menu-contenu">
                    <a href="">Espace communication</a>
                    <a href="">Espace presse</a>
                </div>
             </div>
                
            <div class="col-lg-3 col-md-12 "> 
                <span class="menu-title">Nos sites web</span>
                <div class="menu-contenu">
                    <a href="" >Etudiant du CHU</a>
                    <a href="" >Maternité</a>
                    <a href="" >Projet Infra-LD</a>
                    <a href="" >Réseau ESEO</a>
                    <a href="" >Innovation makes sense</a>
                </div>
            </div>
                
            <div class="col-lg-3 col-md-12 footer-col">  
                <div class="row">
                    <button type="button" class="btn btn-info btn-footer-infopratiques">Dons / Mécénatt</button>
                </div>
                <div class="row">
                    <button type="button" class="btn btn-info btn-footer-infopratiques">Offres d'emploi</button>
                </div>
                <div class="row">
                    <button type="button" class="btn btn-info btn-footer-infopratiques">Professionnels de santé</button>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-12">
            <div class="footer-container">
                <div class="footer-section">
                    <h4>Contact</h4>
                    <a href="tel:+123456789"><i class="fas fa-phone"></i> 02 41 86 67 67</a>
                    <a href="mailto:contact@eshopital.com"><i class="fas fa-envelope"></i> contact@eshopital.com</a>
                    <a href=""> <i class="fas fa-map-marker-alt"></i> 10 Bd Jean Jeanneteau, 49100 Angers</a>
                </div>
                <div class="footer-section">
                    <div class="footer-icare">
                        <h4>Powered by</h4>
                        <div style="margin-top: 0.5em; margin-bottom: 1em;"> 
                            <img width="100px" src="./medias/logo_icare.png" class="img-fluid rounded mx-auto d-block" alt="logo_icare" title="Powered by ICare">
                        </div>
                    </div>
                </div>
                <div class="footer-section">
                    <h4>Nos Réseaux</h4>
                    <a href="https://facebook.com"><i class="fab fa-facebook"></i> Facebook</a>
                    <a href="https://twitter.com"><i class="fab fa-twitter"></i> Twitter</a>
                    <a href="https://linkedin.com"><i class="fab fa-linkedin"></i> LinkedIn</a>
                </div>
            </div>
            <p>© 2025 EsHopital</p>
        </div>
      
        <?php $mysqli->close();
        ?>
    </footer>
</body>

</html>