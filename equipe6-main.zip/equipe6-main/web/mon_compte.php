<?php
    include './core/core.php';
    $_TITRE_PAGE = 'Mon compte ICare';

    //Demande de connexion si non connecté
    if(empty($_SESSION['compte'])){
        header('Location: ./connexion_inscription.php');
        exit;
    }

    $sql = "SELECT	id, nom, prenom, DATE(date_de_naissance) as date_de_naissance, numero_mobile, adresse, email, idGenre
            FROM	Utilisateur
            WHERE	id = '" . $_SESSION['compte'] . "'
        ";

    //exécuter la requête
    $result = $mysqli->query($sql);

    //vérifier qu'il y a un résultat et si oui compte = id de l'utilisateur
    if (!$result) {
        exit($mysqli->error);
    }
    $nb = $result->num_rows;
    if ($nb) {
        //récupération des info utilisateur
        $row = $result->fetch_assoc();
    }

    $sql2 = "SELECT	id, nom, pronom
             FROM	Genre
             WHERE	id = '" . $row['idGenre'] . "'
        ";
    
    //exécuter la requête
    $result_genre = $mysqli->query($sql2);

    //vérifier qu'il y a un résultat et si oui compte = id de l'utilisateur
    if (!$result_genre) {
        exit($mysqli->error);
    }
    $nb2 = $result_genre->num_rows;
    if ($nb2) {
        //récupération des info utilisateur
        $row_genre = $result_genre->fetch_assoc();
    }

    include('./header_all.php') 
?>


<main>
        <div class="row">
            <div class="col-lg-3 col-mg-12">
                <div class="col-nav-menu">
                    <h3>Menu de navigation</h3>
                    <br>
                    <a href="./index.php"> > Accueil</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './mon_compte.php'; ?>"> > Mon compte</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './prendre_rdv.php'; ?>"> > Prendre rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './gestion_rdv.php'; ?>"> > Gérer mes rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './historique_rdv.php'; ?>"> > Historique des rendez-vous</a>
                </div>
            </div>
            <div class="col-lg-9 col-mg-12">
                <div class="col-main-section-general">
                    <div class="main-section-general">
                        <h2>Information générale</h2>
                        <hr/>
                        <h4>Nom</h4>
                        <p><?php echo $row['nom']; ?></p>
                        <h4>Prénom</h4>
                        <p><?php echo $row['prenom']; ?></p>
                        <h4>Sexe</h4>
                        <p><?php echo $row_genre['nom']; ?></p>
                        <h4>Date de naissance</h4>
                        <p><?php echo $row['date_de_naissance']; ?></p>
                    </div>
                    <hr/>
                    <div class="main-section-general">
                        <h2>Contact</h2>
                        <hr/>
                        <h4>Numéro de téléphone</h4>
                        <p><?php echo $row['numero_mobile']; ?></p>
                        <h4>Adresse</h4>
                        <p><?php echo $row['adresse']; ?></p>
                        <h4>Adresse email</h4>
                        <p><?php echo $row['email']; ?></p>
                    </div>
                    <hr/>
                    <div class="d-grid gap-2 col-6 mx-auto" style="margin-bottom: 20px;">
                        <a href="./modification_info_perso.php" class="btn btn-secondary" role="button">Modifier les informations personnelles</a>
                    </div>
                </div>
            </div>
        </div>
    </main>


    <?php
    include('./footer_all.php');
?>









