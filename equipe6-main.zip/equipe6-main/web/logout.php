<?php 
    unset($_SESSION['compte']);
    header("Location: ./index.php");
?>