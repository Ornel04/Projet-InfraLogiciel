<?php  

    // Inclusion sécurisée des fichiers nécessaires
    if (file_exists('./core/core.php')) {
        include('./core/core.php');
    } else {
        die('Erreur : Le fichier système est introuvable.');
    }
    
    $_TITRE_PAGE = 'Accueil';

    if (file_exists('./header_all.php')) {
        include('./header_all.php');
    } else {
        die('Erreur : Le fichier h est introuvable.');
    }

    ?>


    <main>
        <div class="row">
            <div class="col-lg-3 col-mg-12">
                <div class="col-nav-menu">
                    <h3>Menu de navigation</h3>
                    <br>
                    <a href="./index.php"> > Accueil</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './mon_compte.php'; ?>"> > Mon compte</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './prendre_rdv.php'; ?>"> > Prendre rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './gestion_rdv.php'; ?>"> > Gérer mes rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './historique_rdv.php'; ?>"> > Historique des rendez-vous</a>
                </div>
            </div>
            <div class="col-lg-9 col-mg-12">


                <!-- Bande principale avec recherche -->
                <div class="search-banner">
                    <h2>Trouver un service</h2>
                    <div class="search-bar">
                        <input type="text" placeholder="Rechercher un service, un médecin ou un mot-clé..." />
                        <button type="button">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
    
                <!-- Section services -->
                <div class="services">
                    <h2>Services disponibles</h2>
                    <div class="service-grid">
                        <div>
                            <img src="https://via.placeholder.com/200" alt="Service 1">
                            <p>Service 1</p>
                        </div>
                        <div>
                            <img src="https://via.placeholder.com/200" alt="Service 2">
                            <p>Service 2</p>
                        </div>
                        <div>
                            <img src="https://via.placeholder.com/200" alt="Service 3">
                            <p>Service 3</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    

    <?php 
        include('./footer_all.php');
    ?>
