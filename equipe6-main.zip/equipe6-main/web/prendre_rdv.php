<?php
    include './core/core.php';
    $_TITRE_PAGE = 'Prendre RDV';

    //Demande de connexion si non connecté
    if(empty($_SESSION['compte'])){
        header('Location: ./connexion_inscription.php');
        exit;
    }


    include('./header_all.php');
?>


<main>
        <div class="row">
            <div class="col-lg-3 col-mg-12">
                <div class="col-nav-menu">
                    <h3>Menu de navigation</h3>
                    <br>
                    <a href="./index.php"> > Accueil</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './mon_compte.php'; ?>"> > Mon compte</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './prendre_rdv.php'; ?>"> > Prendre rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './gestion_rdv.php'; ?>"> > Gérer mes rendez-vous</a>
                    <a href="<?php echo empty($_SESSION['compte']) ? './connexion_inscription.php' : './historique_rdv.php'; ?>"> > Historique des rendez-vous</a>
                </div>
            </div>
            <div class="col-lg-9 col-mg-12">
                <div class="col-main-section-general">
                    <div class="main-section-general" id="fiche_principale">
                        <h2>Prendre un rendez-vous</h2>
                        </hr>
                        <div class="mb-0" id="fiche_specialite">
							<p>Choisissez une spécialité</p>
							<select name="specialite" id="option_specialite" required class="form-control mb-4">
                                <option value="" selected disabled>-- Sélectionnez une option --</option>
							<?php
								$query_as = $mysqli->query("SELECT id, nom FROM Specialite");
								while ($specialite = $query_as->fetch_object()) {
								?>
								    <option value="<?php echo $specialite->id ?>"><?php echo $specialite->nom ?></option>
								<?php
								}
								?>
				    		</select>
                            <p id="affiche_erreur1"></p>
                            <button id="submit" onclick="getSpe()">Valider</button>
                            <script>
                                function getSpe() {
                                    // Récupère la valeur de l'option choisie
                                    const selectedOption = document.getElementById('options_specialite').value;
                                    
                                    if (selectedOption === "") {
                                        // Affiche un message d'erreur si aucune option n'est sélectionnée
                                        document.getElementById('affiche_erreur1').innerHTML = `<span class="error">Veuillez sélectionner une option avant de valider.</span>`;
                                    } else {
                                        // Recherche des plage horaires et affichage des plus proches
                                        const xhttp = new XMLHttpRequest();
                                        xhttp.onreadystatechange = function() {  //pas de param   
                                            if (this.readyState == 4 && this.status == 200) {
                                                document.getElementById('horaires-table').innerHTML = this.responseText;
                                            }   
                                        }
                                        xhttp.open("POST", "./auxiliaire/getHoraires.php", true);
                                        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                        xhttp.send("selectedOption=" + selectedOption);
                                        sessionStorage.setItem('selectedOption', selectedOption);
                                    }

                                });
                            </script>

                        </div>  
                        </hr>
                        <h1>Horaires Disponibles</h1>
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Début</th>
                                    <th>Fin</th>
                                </tr>
                            </thead>
                            <tbody id="horaires-table">
                                <!-- Les données insérées dynamiquement -->
                            </tbody>
                        </table>
                        <script>
                            // Fonction appelée lorsqu'une ligne du tableau est cliquée
                            function selectRow(row) {
                                // Récupère les données de la ligne cliquée
                                const cells = row.getElementsByTagName('td');
                                const date = cells[0].innerText;
                                const debut = cells[1].innerText;
                                const fin = cells[2].innerText;
                                var selectedOption = sessionStorage.getItem('selectedOption');
                                var userId = <?php echo $_SESSION['compte']; ?>; // On récupère l'ID de l'utilisateur depuis PHP

                                // Recherche des plage horaires et affichage des plus proches
                                const xhttp = new XMLHttpRequest();
                                xhttp.onreadystatechange = function() {   
                                    if (this.readyState == 4 && this.status == 200) {
                                        const response = JSON.parse(this.responseText);

                                        // Récupération des données de la réponse
                                        const idPersonnel = response.idPersonnel;
                                        const idSalle = response.idSalle;
                                        
                                        // Envoi des données à getRDV.php pour afficher le contenu du rendez-vous
                                        // Et enregistrer le rendez-vous dans la base de donnée
                                        const xhttp2 = new XMLHttpRequest();
                                        xhttp2.onreadystatechange = function() {
                                            if (this.readyState == 4 && this.status == 200) {
                                                // Mise à jour du contenu HTML dans l'élément fiche_result
                                                document.getElementById('fiche_result').innerHTML = this.responseText;
                                            }
                                        };
                                        xhttp2.open("POST", "./auxiliaire/getSaveRDV.php", true);
                                        xhttp2.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                        xhttp2.send(
                                            "debut=" + debut + "&" +
                                            "fin=" + fin + "&" +
                                            "confirmation=En attente&" +
                                            "idSalle=" + idSalle + "&" +
                                            "idPersonnel=" + idPersonnel + "&" +
                                            "userId=" + userId
                                        );
                                    }   
                                };

                                xhttp.open("POST", "./auxiliaire/getIdSalleIdPersonnel.php", true);
                                xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                                xhttp.send("selectedOption=" + selectedOption + "&debut=" + debut);

                            }
                        </script>
                    </div>
                    </hr>
                    <div class="main-section-general" id="fiche_principale">
                        <div class="mb-0" id="fiche_result">
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </main>


    <?php
    include('./footer_all.php');
?>









