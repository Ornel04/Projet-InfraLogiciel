rm -rf output-virtualbox-iso
rm -rf *.box
