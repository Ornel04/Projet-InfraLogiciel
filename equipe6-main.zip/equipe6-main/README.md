# Projet Infrastructure et Logiciels: ICare

![Vagrant](https://img.shields.io/badge/Vagrant-1868F2?style=for-the-badge&logo=Vagrant&logoColor=white)
![VirtualBox](https://img.shields.io/badge/VirtualBox-21416b?style=for-the-badge&logo=VirtualBox&logoColor=white)
![MariaDB](https://img.shields.io/badge/MariaDB-003545?style=for-the-badge&logo=mariadb&logoColor=white)

![PHP](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)

![Java](https://img.shields.io/badge/java-%23ED8B00.svg?style=for-the-badge&logo=openjdk&logoColor=white)
![JavaFX](https://img.shields.io/badge/javafx-%23FF0000.svg?style=for-the-badge&logo=javafx&logoColor=white)


## Description

Infrastructure, page web et application Java pour la gestion et prise de rendez-vous pour une consultation en hopital.

L'infrastructure permet la création automatique des machines virtuels pour la base de données et le site web.

La page web sert à prendre et consulter ses rendez-vous pour le client.

L'application Java permet au medecin de gérer les effectifs et leurs plannings.


## Visuals

Pas de visuel disponible actuellement.

## Les pré-requis

### Les ressources informatiques

Pour faire fonctionner les machines virtuels il faut prévoir au moins 2 CPU /coeurs et 4Go de Ram (8Go est plus judicieux). L'espace disque est de l'ordre des 16 Go.
La virtualisation doit être activée sur le PC hôte (machine physique )
<https://support.bluestacks.com/hc/fr-fr/articles/115003174386-Comment-puis-je-activer-la-virtualisation-VT-sur-mon-PC->

### Les applications obligatoires

* Oracle Virtualbox (version 6.1) (<https://www.virtualbox.org/wiki/Downloads>)
* Oracle VM VirtualBox Extension Pack (adapté à la version de virtualbox installée précédement)
* HashiCorp Vagrant (<https://www.vagrantup.com/>)

### Les fichiers obligatoires

* choisir le zip en haut à gauche
* cloner avec git : git clone <https://172.24.7.8/e4e-fise/s7-projet-infra-logiciel/2024-25/equipe6>

Vous trouverez les reperoires/fichiers :

* ./Vagrantfile : qui contient l'ensemble des déclarations pour la construction du Labs
* scripts/install_sys.sh : mise en place des configurations de base sur toutes les VMs
* scripts/install_bdd.sh : Mise en place de la base de données mysql
* scripts/install_moodle.sh : Mise en place de l'application Moodle
* scripts/install_myadmin.sh : Mise en place de l'application PhpMyAdmin
* scripts/install_web.sh : Mise en place du serveur Apache2
* java/* : l'application Java, à compiler et utiliser sur le même réseau que le Lab pour l'utiliser
* web/* : l'ensemble du code du site web

## Installation

Téléchargez la dernière version de ce projet et installer vagrant, VirtualBox et son pack d'extension, depuis ce dossier dans le cmd, lancez la commande 'vagrant up'. La partie infrastructure et web sera mise en place. Pour l'application Java, il faut compiler le code et le lancer sur le même réseau que la partie infrastructure.


## Usage

- L'application Moodle est accéssible par l'adresse <http://192.168.56.80/moodle>
- L'application PhpMyAdmin est accéssible par l'adresse <http://192.168.56.80/myadmin>

Exemple d'utilisation futur:
- Connection sur la page web pour prendre un rendez-vous à un moment choisi avec un spécialiste.
- Envoi de mail automatique pour toute modification du rendez-vous par le personnel soignant.
- Validation ou modification des rendez-vous par un soignant.
- Consultation du planning de la semaine pour un soignant.

## Description des machines virtuels

Le projet est constitué de 3 machine virtuelle Virtualbox basé sur la box fr-book-64
Ces machine sont reliée à votre machine réelle par un réseau privé hôte via les adresse 192.168.56.80 à 192.168.56.82

## Utilisation des commandes vagrant

Télécharger la box modèle
    ```vagrant box add chavinje/fr-book-64```

Activer une VM uniquement (srv-web par exemple)
    ```vagrant up srv-web```

Se connecter à une VM (firewall par exemple)
    ```vagrant ssh firewall```

Arréter une VM (victime par exemple)
    ```vagrant halt victime```

Détruire toutes les VMs (sans demande de confirmation)
    ```vagrant destroy -f```

## Support

Contacter un développeur pour plus d'information ou une correction d'erreur.

## Roadmap

V1: Implémentation d'une première infrastructure, site web et application Java utilisable.

## Authors and acknowledgment

Big thanks to all contributors !

<table>
<tr>
<td><img src="https://gitlab-etu.openstack.etudis.eseo.fr/uploads/-/system/user/avatar/496/avatar.png?width=800" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/e6b55325c11b90b5ababefbe57d72043dc533f893fbce6ba8a64d631432049be?s=1600&d=identicon" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/39d026505b6063bc6e554eb36c9cec0cbc1b6134947412fd48dfa5e3f0651028?s=1600&d=identicon" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/69a822ede95984698fb3706b2e93828699613d5c782b8895c9e31c8b374bbb4b?s=1600&d=identicon" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/a1e2f19c1f0b38775e262bd2effcf3446c802403bed39cd956e0c832b5cac3de?s=1600&d=identicon" width="60px;"/></td>
<td><img src="https://gitlab-etu.openstack.etudis.eseo.fr/uploads/-/system/user/avatar/901/avatar.png?width=800" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/50b64eb5af6fe6a053d481952550045fda8621005a1431fb371a00066d6d4c35?s=1600&d=identicon" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/be8c92174e667b8b756643e4a2e8cb4e0e553aa6865c04ffcc4e5f2948d9dabf?s=1600&d=identicon" width="60px;"/></td>
<td><img src="https://secure.gravatar.com/avatar/68cd76d4efcb2dc55dfb32d6fd0e27ee10e0b9ad2d23d6fd447fc541541fbbb0?s=1600&d=identicon" width="60px;"/></td>
</tr>
<tr>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/jchavin">J. Chavin</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/cconstant">C. Constant</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/srousseau">S. Rousseau</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/asigboal">A. Asigbolo</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/batchara">R. Batcha</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/leguyenz">E. Leguy</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/alain.texier">A. Texier</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/tossouya">E. Tossou Boco</a></td>
<td><a href="https://gitlab-etu.openstack.etudis.eseo.fr/zinsouor">O. ZINSOU-PLY</a></td>
</tr>
</table>


## License
Distributed under the Mozilla Public License. See LICENSE for more information.

## Project status
Just started
