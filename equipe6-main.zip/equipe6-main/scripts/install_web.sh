#!/bin/bash

## install web server with php

IP=$(hostname -I | awk '{print $2}')

APT_OPT="-o Dpkg::Progress-Fancy="0" -q -y"
LOG_FILE="/vagrant/logs/install_web.log"
DEBIAN_FRONTEND="noninteractive"

echo "START - install web Server - "$IP

echo "=> [1]: Installing required packages..."
apt-get install $APT_OPT \
  apache2 \
  php \
  libapache2-mod-php \
  php-mysql \
  php-intl \
  php-curl \
  php-xmlrpc \
  php-soap \
  php-gd \
  php-json \
  php-cli \
  php-pear \
  php-xsl \
  php-zip \
  php-mbstring \
  >> $LOG_FILE 2>&1

#echo "=> [2]: Apache2 configuration"
	# Add configuration of /etc/apache2

  # Step 2: Configure Apache2
echo "=> [2]: Configuring Apache2..."
APACHE_CONF="/etc/apache2/sites-available/000-default.conf"

# Backup existing configuration
sudo cp $APACHE_CONF "${APACHE_CONF}.bak"

# Update DocumentRoot
sudo sed -i 's|DocumentRoot /var/www/html|DocumentRoot /var/www/html/web|' $APACHE_CONF

# Enable required Apache modules
sudo a2enmod rewrite >> $LOG_FILE 2>&1

# Restart Apache to apply changes
sudo systemctl restart apache2 >> $LOG_FILE 2>&1

echo "=> [3]: Test php"

# Copier le fichier index.php depuis le répertoire /vagrant/files vers /var/www/html
sudo cp -r /vagrant/web /var/www/html/web

# Ajuster les permissions du fichier index.php
sudo chown -R www-data:www-data /var/www/html/web
sudo chmod 755 -R /var/www/html/web

echo "=> [4]: Création du lien symbolique pour phpMyAdmin"
# Créer le lien symbolique vers phpMyAdmin
sudo ln -s /var/www/html/phpMyAdmin-5.2.1-all-languages /var/www/html/web/myadmin


echo "END - install web Server"
