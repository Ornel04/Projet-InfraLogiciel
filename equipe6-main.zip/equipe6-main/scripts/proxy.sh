#!/bin/bash

# Mise à jour des paquets et installation d'Apache2
apt-get update 
apt-get install -y apache2

# Activation des modules proxy nécessaires
a2enmod proxy
a2enmod proxy_http

# Configuration du reverse proxy
cat <<EOF > /etc/apache2/sites-available/000-default.conf
<VirtualHost *:80>
    ServerName 192.168.56.82

    # Configuration pour le reverse proxy
    ProxyPreserveHost On
    ProxyPass / http://192.168.56.81/
    ProxyPassReverse / http://192.168.56.81/

</VirtualHost>
EOF

# Activation du site
a2ensite 000-default.conf
systemctl restart apache2

# Activation du module SSL
a2enmod ssl
systemctl restart apache2

# Création du répertoire pour les fichiers SSL
mkdir -p /etc/apache2/ssl

# Génération du certificat SSL auto-signé avec les informations directement fournies
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/apache2/ssl/private.key -out /etc/apache2/ssl/certificate.crt -subj "/C=FR/ST=Maine-et-Loire/L=Angers/O=ESEO/OU=ESEO-CSS/CN=192.168.56.82/emailAddress=ornel.zinsouply@reseau.eseo.fr"


# Modification de la configuration du site SSL
cat <<EOF > /etc/apache2/sites-available/default-ssl.conf
<VirtualHost *:443>
    ServerAdmin webmaster@localhost

    # Configuration pour le reverse proxy sécurisé
    ProxyPreserveHost On
    ProxyPass / http://192.168.56.81/
    ProxyPassReverse / http://192.168.56.81/

    # Log files
    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined

    # Activation de SSL
    SSLEngine on

    # Certificats SSL
    SSLCertificateFile /etc/apache2/ssl/certificate.crt
    SSLCertificateKeyFile /etc/apache2/ssl/private.key

    # Autres configurations SSL (commentées par défaut)
    #SSLCertificateChainFile /etc/apache2/ssl.crt/server-ca.crt
    #SSLCACertificatePath /etc/ssl/certs/
    #SSLCACertificateFile /etc/apache2/ssl.crt/ca-bundle.crt
    #SSLCARevocationPath /etc/apache2/ssl.crl/
    #SSLCARevocationFile /etc/apache2/ssl.crl/ca-bundle.crl

    # Client Authentication (optional)
    #SSLVerifyClient require
    #SSLVerifyDepth 10

    # SSL Engine Options
    #SSLOptions +FakeBasicAuth +ExportCertData +StrictRequire
    <FilesMatch "\.(?:cgi|shtml|phtml|php)$">
        SSLOptions +StdEnvVars
    </FilesMatch>
    <Directory /usr/lib/cgi-bin>
        SSLOptions +StdEnvVars
    </Directory>

    # SSL Protocol Adjustments
    # BrowserMatch "MSIE [2-6]" \
    #    nokeepalive ssl-unclean-shutdown \
    #    downgrade-1.0 force-response-1.0

</VirtualHost>
EOF

# Activation du site SSL
a2ensite default-ssl.conf

# Redémarrage d'Apache pour appliquer toutes les modifications
systemctl restart apache2
