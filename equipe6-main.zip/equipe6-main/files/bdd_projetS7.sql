/*CREATE USER 'moodle_user'@'localhost' IDENTIFIED BY 'network';

CREATE DATABASE moodle DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
GRANT ALL PRIVILEGES ON moodle.* TO moodle_user@localhost;

USE moodle;*/

CREATE TABLE Genre
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(255),
    pronom VARCHAR(255),
    titre_civilite VARCHAR(255)
);

INSERT INTO Genre (id, nom, pronom, titre_civilite) VALUES
(1, 'Homme', 'il/lui', 'Monsieur'),
(2, 'Femme', 'elle/elle', 'Madame');

CREATE TABLE Utilisateur
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(255),
    prenom VARCHAR(255),
	date_de_naissance DATETIME,
    numero_mobile VARCHAR(13),
    adresse VARCHAR(255),
    email VARCHAR(255),
    mot_de_passe VARCHAR(20),
    idGenre BIGINT NOT NULL,
    FOREIGN KEY (idGenre) REFERENCES Genre(id)
);

INSERT INTO Utilisateur (id, nom, prenom, date_de_naissance, numero_mobile, adresse, email, mot_de_passe, idGenre) VALUES
(1, 'Dupont', 'Pierre', '1990-05-15', '33123456789', '123 Rue de Paris', 'pierre.dupont@gmail.com', 'password123', 1),
(2, 'Martin', 'Sophie', '1985-08-22', '33698765432', '456 Avenue des Champs', 'sophie.martin@gmail.com', 'password456', 2);

CREATE TABLE Service
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(255)
);

INSERT INTO Service (id, nom) VALUES
(1, 'Cardiologie'),
(2, 'Radiologie');

CREATE TABLE Specialite
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(255),
    idService BIGINT NOT NULL,
    FOREIGN KEY (idService) REFERENCES Service(id)
);

INSERT INTO Specialite (id, nom, idService) VALUES
(1, 'Cardiologue', 1),
(2, 'Radiologue', 2);

CREATE TABLE Salle
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(255)
);

INSERT INTO Salle (id, nom) VALUES
(1, 'Salle 405'),
(2, 'Salle 206');

CREATE TABLE SpecialiteSalle (
    idSalle BIGINT NOT NULL,
    idSpecialite BIGINT NOT NULL,
    FOREIGN KEY (idSalle) REFERENCES Salle(id),
    FOREIGN KEY (idSpecialite) REFERENCES Specialite(id),
    PRIMARY KEY (idSalle, idSpecialite)
);

INSERT INTO SpecialiteSalle (idSalle, idSpecialite) VALUES
(1, 1),
(2, 2);

CREATE TABLE Personnel
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    role ENUM('Aucun', 'Chef de service', 'Administrateur') NOT NULL,
    idService BIGINT NOT NULL,
    idSalle BIGINT NOT NULL,
    idUtilisateur BIGINT NOT NULL,
    FOREIGN KEY (idService) REFERENCES Service(id),
    FOREIGN KEY (idSalle) REFERENCES Salle(id),
    FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur(id)
);

INSERT INTO Personnel (id, role, idService, idSalle, idUtilisateur) VALUES
(1, 'Chef de service', 1, 1, 1),
(2, 'Administrateur', 2, 2, 2);

CREATE TABLE SpecialitePersonnel (
    idPersonnel BIGINT NOT NULL ,
    idSpecialite BIGINT NOT NULL ,
    FOREIGN KEY (idPersonnel) REFERENCES Personnel(id),
    FOREIGN KEY (idSpecialite) REFERENCES Specialite(id),
    PRIMARY KEY (idPersonnel, idSpecialite)
);

INSERT INTO SpecialitePersonnel (idPersonnel, idSpecialite) VALUES
(1, 1),
(2, 2);

CREATE TABLE Disponibilite
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    debut DATETIME,
    fin DATETIME,
    idPersonnel BIGINT NOT NULL,
    FOREIGN KEY (idPersonnel) REFERENCES Personnel(id)
);

INSERT INTO Disponibilite (id, debut, fin, idPersonnel) VALUES
(1, '2025-01-24 09:00:00', '2025-01-24 17:00:00', 1),
(2, '2025-01-24 08:00:00', '2025-01-24 16:00:00', 2);

CREATE TABLE RDV
(
    id BIGINT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    nom VARCHAR(255),
    debut DATETIME,
    fin DATETIME,
    confirmation ENUM('confirme','en attente') NOT NULL,
    idUtilisateur BIGINT NOT NULL,
	idSalle BIGINT NOT NULL,
	idPersonnel BIGINT NOT NULL,
    FOREIGN KEY (idUtilisateur) REFERENCES Utilisateur(id),
    FOREIGN KEY (idSalle) REFERENCES Salle(id),
    FOREIGN KEY (idPersonnel) REFERENCES Personnel(id)
);

INSERT INTO RDV (id, nom, debut, fin, confirmation, idUtilisateur, idSalle, idPersonnel) VALUES
(1, 'Consultation Cardiologie', '2023-10-15 10:00:00', '2023-10-15 11:00:00', 'confirme', 1, 1, 1),
(2, 'Examen Radiologie', '2023-10-16 09:00:00', '2023-10-16 10:00:00', 'en attente', 2, 2, 2);