package src.vue;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import src.model.Utilisateur;

public class VueUtilisateur extends GridPane{
    Utilisateur utilisateur;
    Label nom;
    Label prenom;
    Label date_de_naissance;
    Label numero_mobile;
    Label adresse;
    Label email;
    Label Genre;

    public VueUtilisateur(){
        super();
        String[] affichages = {"Nom", "Prenom", "Date de naissance", "Numero mobile", "Adresse", "Email", "Genre"};
        for(int i=0;i<affichages.length;i++){
            this.add(new Label(affichages[i]+" :"),0,i);
        }
        nom = new Label("");
        this.add(nom,1,0);
        prenom = new Label("");
        this.add(prenom,1,1);
        date_de_naissance = new Label("");
        this.add(date_de_naissance,1,2);
        numero_mobile = new Label("");
        this.add(numero_mobile,1,3);
        adresse = new Label("");
        this.add(adresse,1,4);
        email = new Label("");
        this.add(email,1,5);
        Genre = new Label("");
        this.add(Genre,1,6);
    }

    public void setUtilisateur(Utilisateur utilisateur){
        if(utilisateur==null){
            this.utilisateur = null;
            this.nom.setText("");
            this.prenom.setText("");
            this.date_de_naissance.setText("");
            this.numero_mobile.setText("");
            this.adresse.setText("");
            this.email.setText("");
            this.Genre.setText("");
            return;
        }
        this.utilisateur = utilisateur;
        this.nom.setText(utilisateur.getNom());
        this.prenom.setText(utilisateur.getPrenom());
        this.date_de_naissance.setText(utilisateur.getDate_de_naissance().toString());
        this.numero_mobile.setText(utilisateur.getNumero_mobile());
        this.adresse.setText(utilisateur.getAdresse());
        this.email.setText(utilisateur.getEmail());
        this.Genre.setText(utilisateur.getGenre());
    }

}
