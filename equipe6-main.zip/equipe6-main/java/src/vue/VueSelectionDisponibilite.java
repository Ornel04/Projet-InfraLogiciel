package src.vue;

import javafx.scene.layout.GridPane;

import java.time.LocalDate;
import java.time.chrono.Chronology;

import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.DatePicker;
import src.controler.SelectionDisponibiliteControler;
import src.model.ICare;

public class VueSelectionDisponibilite extends GridPane{

    private SelectionDisponibiliteControler selectionDisponibiliteControler;
    DatePicker datePickerDebutDisponibilite;
    DatePicker datePickerFinDisponibilite;
    ComboBox<Integer> comboBoxHeureDebutDisponibilite;
    ComboBox<Integer> comboBoxMinuteDebutDisponibilite;
    ComboBox<Integer> comboBoxHeureFinDisponibilite;
    ComboBox<Integer> comboBoxMinuteFinDisponibilite;

    public VueSelectionDisponibilite(ICare iCare){
        super();
        selectionDisponibiliteControler = new SelectionDisponibiliteControler(this, iCare);
        this.add(new Label("Création Disponibilite"), 0, 0, 4,1);
        datePickerDebutDisponibilite = new DatePicker();
        datePickerFinDisponibilite = new DatePicker();
        add(new Label("Date de début"), 1, 1);
        add(new Label("Date de fin"), 3, 1);
        this.add(datePickerDebutDisponibilite, 1, 2);
        this.add(datePickerFinDisponibilite, 3, 2);
        comboBoxHeureDebutDisponibilite = new ComboBox<Integer>();
        comboBoxMinuteDebutDisponibilite = new ComboBox<Integer>();
        comboBoxHeureFinDisponibilite = new ComboBox<Integer>();
        comboBoxMinuteFinDisponibilite = new ComboBox<Integer>();
        for(int i=0;i<24;i++){
            comboBoxHeureDebutDisponibilite.getItems().add(i);
            comboBoxHeureFinDisponibilite.getItems().add(i);
        }
        for(int i=0;i<60;i+=15){
            comboBoxMinuteDebutDisponibilite.getItems().add(i);
            comboBoxMinuteFinDisponibilite.getItems().add(i);
        }
        add(new Label("Heure de début"), 0, 3);
        add(comboBoxHeureDebutDisponibilite, 1, 3);
        add(new Label("Minute de début"), 2, 3);
        add(comboBoxMinuteDebutDisponibilite, 3, 3);
        add(new Label("Heure de fin"), 0, 4);
        add(comboBoxHeureFinDisponibilite, 1, 4);
        add(new Label("Minute de fin"), 2, 4);
        add(comboBoxMinuteFinDisponibilite, 3, 4);
        Button buttonAjoutDisponibilite = new Button("Ajouter Disponibilite");
        buttonAjoutDisponibilite.setOnAction(event -> selectionDisponibiliteControler.ajoutDisponibilite());
        add(buttonAjoutDisponibilite,0,5,4,1);

        this.setVisible(false);
    }

    public LocalDate getDebutDisponibilite(){
        return datePickerDebutDisponibilite.getValue();
    }

    public LocalDate getFinDisponibilite(){
        return datePickerFinDisponibilite.getValue();
    }

    public int getHeureDebutDisponibilite(){
        return comboBoxHeureDebutDisponibilite.getSelectionModel().getSelectedItem();
    }

    public int getMinuteDebutDisponibilite(){
        return comboBoxMinuteDebutDisponibilite.getSelectionModel().getSelectedItem();
    }

    public int getHeureFinDisponibilite(){
        return comboBoxHeureFinDisponibilite.getSelectionModel().getSelectedItem();
    }

    public int getMinuteFinDisponibilite(){
        return comboBoxMinuteFinDisponibilite.getSelectionModel().getSelectedItem();
    }
}