package src.vue;

import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import src.controler.RDVController;
import src.model.BaseDeDonnee;
import src.model.Personnel;
import src.model.Planning;
import src.model.RDV;
import src.model.Salle;

public class VueRDV extends VBox{
    private RDV rdv;
    private RDVController rdvController;

    private Label titre;
    private VueUtilisateur vueUtilisateur;
    private ComboBox<Salle> salleComboBox;
    private ComboBox<Personnel> personnelComboBox;
    private ComboBox<String> isValideComboBox;

    public VueRDV(){
        super();
        RDVController rdvController = new RDVController(this);
        titre = new Label("Titre Rendez-vous");
        vueUtilisateur = new VueUtilisateur();
        salleComboBox = new ComboBox<Salle>();
        salleComboBox.setConverter(Salle.getStringConverter());
        personnelComboBox = new ComboBox<Personnel>();
        personnelComboBox.setConverter(Personnel.getStringConverter());
        isValideComboBox = new ComboBox<String>();
        this.getChildren().addAll(titre, vueUtilisateur, salleComboBox, personnelComboBox, isValideComboBox);
    }

    public void setRDVController(RDVController rdvController){
        this.rdvController = rdvController;
    }

    public RDVController getRDVController(){
        return rdvController;
    }

    public void updateRDV(RDV rdv){
        this.rdv = rdv;
        if(rdv==null){
            titre.setText("Titre Rendez-vous");
            vueUtilisateur.setUtilisateur(null);
        }
        else{
            titre.setText(rdv.getNom());
            vueUtilisateur.setUtilisateur(rdv.getUtilisateur());
        }
        updateSalle();
        updatePersonnel();
        updateValidation();
    }

    private void updateSalle(){
        Salle[] salles = BaseDeDonnee.getSalles();
        salleComboBox.setOnAction(null);
        salleComboBox.getItems().clear();
        if(rdv==null){
            salleComboBox.getSelectionModel().select(null);
            return;
        }
        salleComboBox.getItems().addAll(salles);
        salleComboBox.getSelectionModel().select(rdv.getSalle());
        salleComboBox.setOnAction(event->rdvController.updateSalle());
    }

    private void updatePersonnel(){
        Personnel[] personnels = BaseDeDonnee.getPersonnels();
        personnelComboBox.setOnAction(null);
        if(rdv==null){
            personnelComboBox.getSelectionModel().select(null);
            return;
        }
        personnelComboBox.getItems().clear();
        personnelComboBox.getItems().addAll(personnels);
        personnelComboBox.getSelectionModel().select(rdv.getPersonnel());
        personnelComboBox.setOnAction(event->rdvController.updatePersonnel());
    }

    private void updateValidation(){
        isValideComboBox.setOnAction(null);
        if(rdv==null){
            return;
        }
        isValideComboBox.getItems().clear();
        if(!rdv.isValide()){
            isValideComboBox.getItems().addAll("En attente de confirmation", "Valide", "Annuler");
            isValideComboBox.getSelectionModel().select("En attente de confirmation");
        }else{
            isValideComboBox.getItems().addAll("Valide", "Annuler");
            isValideComboBox.getSelectionModel().select("Valide");
        }
        isValideComboBox.setOnAction(event->rdvController.updateValidation());
    }

    public RDV getRDV(){
        return rdv;
    }

    public void setRDV(RDV rdv){
        this.rdv = rdv;
    }

    public ComboBox<Salle> getSalleComboBox(){
        return salleComboBox;
    }

    public ComboBox<Personnel> getPersonnelComboBox(){
        return personnelComboBox;
    }

    public ComboBox<String> getIsValideComboBox(){
        return isValideComboBox;
    }

    public void setPlanning(Planning planning){
        rdvController.setPlanning(planning);
    }
}
