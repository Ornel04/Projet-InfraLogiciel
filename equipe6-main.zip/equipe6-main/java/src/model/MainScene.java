package src.model;

import javafx.scene.Scene;
import src.vue.VueRDV;
import src.vue.VueSelectionDisponibilite;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class MainScene extends Scene{

    private Planning planning;
    private VueRDV vueRDV;
    private VueSelectionDisponibilite vueSelectionDisponibilite;

    public MainScene(ICare iCare){
        this(new VBox(10), iCare);
    }

    public MainScene(VBox root, ICare iCare){
        super(root, 900, 500);
        vueRDV = new VueRDV();
        vueSelectionDisponibilite = new VueSelectionDisponibilite(iCare);
        StackPane panneauInformation = new StackPane();
        panneauInformation.getChildren().addAll(vueRDV, vueSelectionDisponibilite);
        planning = new Planning(this, vueRDV, iCare);
        HBox hBox = new HBox(10);
        hBox.getChildren().add(planning);
        hBox.getChildren().add(panneauInformation);
        MenuBar menuBar = new MenuBar();
        menuBar.prefWidthProperty().bind(iCare.widthProperty());
        Menu fileMenu = new Menu("File");
        Menu editMenu = new Menu("Edit");
        MenuItem ajoutDisponibilite = new MenuItem("ajoutDisponibilite");
        ajoutDisponibilite.setOnAction(event -> showVueSelectionDisponibilite());
        menuBar.getMenus().addAll(fileMenu, editMenu);
        MenuItem deconnexioMenuItem = new MenuItem("Deconnexion");
        deconnexioMenuItem.setOnAction(event -> iCare.deconnexion());
        fileMenu.getItems().add(deconnexioMenuItem);
        editMenu.getItems().add(ajoutDisponibilite);
        root.getChildren().addAll(menuBar, hBox);
    }

    public void showVueRDV(){
        vueRDV.setVisible(true);
        vueSelectionDisponibilite.setVisible(false);
    }

    public void showVueSelectionDisponibilite(){
        vueRDV.setVisible(false);
        vueSelectionDisponibilite.setVisible(true);
    }
}
