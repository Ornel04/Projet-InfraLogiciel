package src.model;

import java.sql.Date;
import java.util.ArrayList;
import javafx.util.StringConverter;

public class Personnel extends Utilisateur{
    enum Role{
        AUCUN,
        CHEF_DE_SERVICE,
        ADMINISTRATEUR
    }
    String service;
    ArrayList<String> specialites;
    Role role;
    int idSalleParDefaut;

    public Personnel(int id, String nom, String prenom, Date date_de_naissance, String numero_mobile, String adresse, String email, String genre){
        super(id, nom, prenom, date_de_naissance, numero_mobile, adresse, email, genre);
    }

    public boolean equals(Object object){
        if(object instanceof Personnel){
            Personnel personnel = (Personnel) object;
            return personnel.getId() == this.getId();
        }else{
            return false;
        }
    }

    public static StringConverter<Personnel> getStringConverter(){
        return new StringConverter<Personnel>() {
            @Override
            public String toString(Personnel object) {
                if(object != null){
                    return object.getNom();
                }else{
                    return "Personnel";
                }
            }
        
            @Override
            public Personnel fromString(String string) {
                return null;
            }
        };
    }

    public int getId(){
        return id;
    }
}
