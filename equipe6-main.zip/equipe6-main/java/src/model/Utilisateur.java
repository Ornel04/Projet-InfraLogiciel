package src.model;

import java.sql.Date;

public class Utilisateur {
    int id;
    String nom;
    String prenom;
	Date date_de_naissance;
    String numero_mobile;
    String adresse;
    String email;
    String Genre;
    String pronom;
    String titreDeCivilite;

    Utilisateur(int id, String nom, String prenom, Date date_de_naissance, String numero_mobile, String adresse, String email, String Genre){
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.date_de_naissance = date_de_naissance;
        this.numero_mobile = numero_mobile;
        this.adresse = adresse;
        this.email = email;
        this.Genre = Genre;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public Date getDate_de_naissance() {
        return date_de_naissance;
    }

    public String getNumero_mobile() {
        return numero_mobile;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getEmail() {
        return email;
    }

    public String getGenre() {
        return Genre;
    }

    public String getPronom() {
        return pronom;
    }

    public String getTitreDeCivilite() {
        return titreDeCivilite;
    }
}
