package src.model;

import java.time.Instant;

public class RDV {
    int id;
    int idUtilisateur;
    int idSalle;
    int idPersonnel;
    String nom;
    Instant debut;
    Instant fin;
    boolean isValide;
    RDV(int id, int idUtilisateur, int idSalle, int idPersonnel ,String nom, Instant debut, Instant fin, boolean isValide){
        this.id=id;
        this.idUtilisateur = idUtilisateur;
        this.idSalle = idSalle;
        this.idPersonnel = idPersonnel;
        this.nom = nom;
        this.debut = debut;
        this.fin = fin;
        this.isValide = isValide;
    }

    public String getNom(){
        return nom;
    }

    public Utilisateur getUtilisateur(){
        return BaseDeDonnee.getUtilisateur(idUtilisateur);
    }

    public Salle getSalle(){
        return BaseDeDonnee.getSalle(idSalle);
    }

    public void setSalle(Salle salle){
        idSalle = salle.getId();
    }

    public Personnel getPersonnel(){
        return BaseDeDonnee.getPersonnel(idPersonnel);
    }

    public void setPersonnel(Personnel personnel){
        idPersonnel = personnel.getId();
    }

    public boolean isValide(){
        return isValide;
    }

    public void setValide(boolean valide){
        isValide = valide;
    }

    public boolean equals(RDV rdv){
        if(rdv == null){
            return false;
        }
        if(!(rdv instanceof RDV)){
            return false;
        }
        if(rdv == this){
            return true;
        }
        return rdv.idUtilisateur == idUtilisateur && rdv.idSalle == idSalle && rdv.idPersonnel == idPersonnel && rdv.debut.equals(debut) && rdv.fin.equals(fin);
    }

    public int getId(){
        return id;
    }
}
