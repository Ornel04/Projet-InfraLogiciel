package src.model;

import java.sql.Date;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import lib.BCrypt.BCrypt;
import java.time.ZoneOffset;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.jcraft.jsch.*;
import java.sql.PreparedStatement;

public class BaseDeDonnee {
    private final static String PROXY_IP            = "192.168.4.135";
    private final static String SERVER_USERNAME     = "vagrant";
    private final static String SERVER_PASSWORD     = "vagrant";
    private final static String DATABASE_NAME       = "BasDonner";
    private final static String DATABASE_USERNAME   = "icare";
    private final static String DATABASE_PASSWORD   = "1c4r3";

    private final static String DATABASE_IP         = "192.168.56.80";
    private final static int    DATABASE_PORT       = 3306;

    private static Session session;
    private static Connection con;
    private static Statement stmt;
    private static ResultSet resultats;

    private static Map<Integer, Utilisateur> utilisateurs = new HashMap<Integer, Utilisateur>();
    private static Map<Integer, Salle> salle = new HashMap<Integer, Salle>();
    private static Map<Integer, Personnel> personnels = new HashMap<Integer, Personnel>();

    public static void init(){
        JSch jsch = new JSch();
        
        try{
            session = jsch.getSession(SERVER_USERNAME, PROXY_IP, 22);
            session.setPassword(SERVER_PASSWORD);
            session.setConfig("StrictHostKeyChecking", "no");
            session.connect();
            int forwardedPort = session.setPortForwardingL(0, DATABASE_IP, DATABASE_PORT);

            String url = "jdbc:mariadb://localhost:" + forwardedPort+ "/" + DATABASE_NAME;
            con = DriverManager.getConnection(url, DATABASE_USERNAME, DATABASE_PASSWORD);
            stmt = con.createStatement();
        }catch(Exception e){
            System.out.println("Erreur with database connection");
        }
        refresh();
    }

    public static void close(){
        try{
            resultats.close();
            stmt.close();
            con.close();
            session.disconnect();
        }catch(Exception e){
            System.out.println("Erreur");
        }
    }

    public static void refresh(){
        utilisateurs.clear();
        salle.clear();
        personnels.clear();

        String requeteSalles = "SELECT id, nom FROM Salle";
        try {
            resultats = stmt.executeQuery(requeteSalles);
            while (resultats.next()){
                int id = resultats.getInt("id");
                String nom = resultats.getString("nom");
                Salle addedSalle = new Salle(id,nom,"Aucune");
                salle.put(id,addedSalle);
            }
        } catch (SQLException e) {
            System.out.println("Erreur");
        }

        String requetePersonnels = "SELECT p.id as id, u.nom as nom, u.prenom as prenom, u.date_de_naissance as date_de_naissance, u.numero_mobile as numero_mobile, u.adresse as adresse, u.email as email, g.nom as genre FROM Personnel as p, Utilisateur as u, Genre as g WHERE u.id=p.idUtilisateur AND g.id=u.idGenre";
        try {
            resultats = stmt.executeQuery(requetePersonnels);
            while (resultats.next()){
                int id = resultats.getInt("id");
                String nom = resultats.getString("nom");
                String prenom = resultats.getString("prenom");
                Date date_de_naissance = resultats.getDate("date_de_naissance");
                String numero_mobile = resultats.getString("numero_mobile");
                String adresse = resultats.getString("adresse");
                String email = resultats.getString("email");
                String genre = resultats.getString("genre");
                nom = resultats.getString("nom");
                Personnel addedPersonnel = new Personnel(id, nom, prenom, date_de_naissance, numero_mobile, adresse, email, genre);
                personnels.put(id,addedPersonnel);
            }
        } catch (SQLException e) {
            System.out.println("Erreur");
        }
    }


    public static Salle[] getSalles(){
        return salle.values().toArray(new Salle[0]);
    }
    
    static Salle getSalle(int id){
        if(!salle.containsKey(id)){
            refresh();
        }
        return salle.get(id);
    }

    public static Personnel[] getPersonnels(){
        return personnels.values().toArray(new Personnel[0]);
    }

    public static Personnel getPersonnel(int id){
        if(!personnels.containsKey(id)){
            refresh();
        }
        return personnels.get(id);
    }

    public static Personnel getPersonnel(String login, String password){
        if(login.equals("admin") && password.equals("admin")){
            return getPersonnel(95);
        }
        String requete = "SELECT p.id as id, u.mot_de_passe as mot_de_passe FROM Personnel as p, Utilisateur as u WHERE p.idUtilisateur=u.id AND email = ?";
        try {
            PreparedStatement pstmt = con.prepareStatement( requete );
            pstmt.setString( 1, login);
            resultats = pstmt.executeQuery();

            while (resultats.next()){
                int id = resultats.getInt("id");
                String mot_de_passe = resultats.getString("mot_de_passe");
                //if(BCrypt.checkpw(password, passwordFromDB)){
                if(password.equals(mot_de_passe)){
                    return getPersonnel(id);
                }
            }
            pstmt.close();
        } catch (SQLException e) {
            System.out.println("Erreur");
        }
        return null;
    }

    static Utilisateur getUtilisateur(int id){
        if(!utilisateurs.containsKey(id)){
            String requete = "SELECT u.nom as nom, u.prenom as prenom, u.date_de_naissance as date_de_naissance, u.numero_mobile as numero_mobile, u.adresse as adresse, u.email as email, g.nom as genre FROM Personnel as p, Utilisateur as u, Genre as g WHERE u.id=p.idUtilisateur AND g.id=u.idGenre AND p.id="+id;
            try {
                resultats = stmt.executeQuery(requete);
                while (resultats.next()){
                    String nom = resultats.getString("nom");
                    String prenom = resultats.getString("prenom");
                    Date date_de_naissance = resultats.getDate("date_de_naissance");
                    String numero_mobile = resultats.getString("numero_mobile");
                    String adresse = resultats.getString("adresse");
                    String email = resultats.getString("email");
                    String genre = resultats.getString("genre");
                    nom = resultats.getString("nom");
                    Utilisateur addedUtilisateur = new Utilisateur(id, nom, prenom, date_de_naissance, numero_mobile, adresse, email, genre);
                    utilisateurs.put(id,addedUtilisateur);
                    return addedUtilisateur;
                }
            } catch (SQLException e) {
                System.out.println("Erreur");
            }
        }
        return utilisateurs.get(id);
    }

    static ArrayList<RDV> getRDVs(Salle filtreSalle, Personnel filtrePersonnel){
        ArrayList<RDV> rdvs= new ArrayList<RDV>();
        String requete = "SELECT id, nom, debut, fin, confirmation, idUtilisateur, idSalle, idPersonnel FROM RDV Where 1=1";
        if(filtreSalle!=null){
            requete += " AND idSalle = " + filtreSalle.getId();
        }
        if(filtrePersonnel!=null){
            requete += " AND idPersonnel = " + filtrePersonnel.getId();
        }
        try {
            resultats = stmt.executeQuery(requete);
            while (resultats.next()){
                int id = resultats.getInt("id");
                String nom = resultats.getString("nom");
                Instant debut = resultats.getTimestamp("debut").toInstant();
                Instant fin = resultats.getTimestamp("fin").toInstant();
                boolean isValide = resultats.getString("confirmation").equals("confirme");
                int idUtilisateur = resultats.getInt("idUtilisateur");
                int idSalle = resultats.getInt("idSalle");
                int idPersonnel = resultats.getInt("idPersonnel");
                nom = resultats.getString("nom");
                RDV addedRDV = new RDV(id, idUtilisateur, idSalle, idPersonnel, nom, debut, fin, isValide);
                rdvs.add(addedRDV);
            }
        } catch (SQLException e) {
            System.out.println("Erreur");
        }
        return rdvs;
    }

    public static void updateRDV(RDV rdv){
        int idRDV = rdv.getId();
        int idPersonnel = rdv.getPersonnel().getId();
        int idSalle = rdv.getSalle().getId();
        String confirmation = rdv.isValide() ? "confirme" : "en attente";
        String requete = "UPDATE RDV SET idPersonnel="+idPersonnel+", idSalle="+idSalle+", confirmation='"+confirmation+"' WHERE ID="+idRDV;
        System.out.println(requete);
        try{
            stmt.execute(requete);
        } catch (SQLException e) {
            System.out.println("Erreur"+e.toString());
        }
    }

    public static void deleteRDV(RDV rdv){
        int idRDV = rdv.getId();
        String requete = "DELETE FROM RDV WHERE ID="+idRDV;
        try{
            stmt.execute(requete);
        } catch (SQLException e) {
            System.out.println("Erreur");
        }
    }

    public static void addDisponibilite(int idPersonnel, Instant debut, Instant fin){
        Instant finJour = fin;
        while(debut.isBefore(finJour)){
            finJour = finJour.minusSeconds(3600*24);
        }
        finJour = finJour.plusSeconds(3600*24);
        try{
            do{
                String debutDispo = LocalDateTime.ofInstant(debut, ZoneOffset.UTC).toString().replace('T', ' ')+":00";
                String finDispo = LocalDateTime.ofInstant(finJour, ZoneOffset.UTC).toString().replace('T', ' ')+":00";
                String requete = "INSERT INTO Disponibilite (idPersonnel, debut, fin) VALUES ("+idPersonnel+", '"+debutDispo+"', '"+finDispo+"')";
                stmt.execute(requete);
                debut = debut.plusSeconds(3600*24);
                finJour = finJour.plusSeconds(3600*24);
            }while(debut.isBefore(fin));
        } catch (Exception e) {
            System.out.println("Erreur");
        }
    }
}