package src.model;

import javafx.util.StringConverter;

public class Salle {
    int id;
    String nom;
    String specialite;
    
    public Salle(int id, String nom, String specialite){
        this.id = id;
        this.nom = nom;
        this.specialite = specialite;
    }

    public int getId(){
        return id;
    }

    public String getNom(){
        return nom;
    }

    public String getSpecialite(){
        return specialite;
    }

    public boolean equals(Object object){
        if(object instanceof Salle){
            Salle salle = (Salle) object;
            return salle.getId() == this.getId();
        }else{
            return false;
        }
    }

    public static StringConverter<Salle> getStringConverter(){
        return new StringConverter<Salle>() {
            @Override
            public String toString(Salle object) {
                if(object != null){
                    return object.getNom();
                }else{
                    return "Salle";
                }
            }
        
            @Override
            public Salle fromString(String string) {
                return null;
            }
        };
    }
}
