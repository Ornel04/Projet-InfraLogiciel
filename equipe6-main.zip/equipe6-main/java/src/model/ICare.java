package src.model;

import javafx.application.Application;
import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.stage.Stage;

public class ICare extends Application {

    private Stage stage;
    private Personnel comptePersonnel;
    private Connexion connexion;

    @Override
    public void start(Stage stage) throws Exception {
        this.stage = stage;
        BaseDeDonnee.init();
        connexion = new Connexion(this);
        stage.setScene(connexion);
        stage.setTitle("ICare");
        stage.show();
    }

    @Override
    public void stop(){
        BaseDeDonnee.close();
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void connexion(Personnel comptePersonnel) {
        this.comptePersonnel = comptePersonnel;
        stage.setScene(new MainScene(this));
    }

    public void deconnexion(){
        this.comptePersonnel = null;
        stage.setScene(connexion);
    }

    public ReadOnlyDoubleProperty widthProperty() {
        return stage.widthProperty();
    }

    public Personnel getComptePersonnel() {
        return comptePersonnel;
    }

}