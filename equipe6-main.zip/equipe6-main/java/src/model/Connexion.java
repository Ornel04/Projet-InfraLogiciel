package src.model;

import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Label;
import javafx.scene.control.Button;

public class Connexion extends Scene {

    public Connexion(ICare iCare){
        this(new GridPane(), iCare);
    }

    public Connexion(GridPane root, ICare iCare){
        super(root, 300, 200);
        BaseDeDonnee.refresh();
        TextField login = new TextField();
        PasswordField password = new PasswordField();
        Button connexion = new Button("Connexion");
        connexion.setOnAction(e -> {
            Personnel personnel = BaseDeDonnee.getPersonnel(login.getText(), password.getText());
            if(personnel != null){
                iCare.connexion(personnel);
                login.clear();
                password.clear();
            }
        });
        root.add(new Label("Login"),0,0);
        root.add(new Label("Password"),0,1);
        root.add(login,1,0);
        root.add(password,1,1);
        root.add(connexion,1,2, 2, 1);
    }
}