package src.model;

import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;

import java.util.ArrayList;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import src.controler.RDVController;
import src.vue.VueRDV;
import javafx.scene.layout.ColumnConstraints;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.HashMap;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;

//TODO pb si reservation sur minuit; pb si reservation sur plusieurs jours

public class Planning extends VBox{

    private VueRDV vueRDV;
    private ArrayList<RDV> rdvs;
    private MainScene mainScene;
    private GridPane gridPane;
    private ComboBox<Salle> salleComboBox;
    private ComboBox<Personnel> personnelComboBox;

    Planning(MainScene mainScene,VueRDV vueRDV, ICare iCare){
        super();
        gridPane = new GridPane();
        this.mainScene = mainScene;
        vueRDV.setPlanning(this);
        this.vueRDV = vueRDV;
        salleComboBox = new ComboBox<Salle>();
        salleComboBox.setConverter(Salle.getStringConverter());
        personnelComboBox = new ComboBox<Personnel>();
        personnelComboBox.setConverter(Personnel.getStringConverter());
        updateSalle();
        updatePersonnel();
        personnelComboBox.setOnAction(null);
        personnelComboBox.getSelectionModel().select(iCare.getComptePersonnel());
        personnelComboBox.setOnAction(event->refresh());
        this.miseEnFormeGrid();
        this.addRDV();
        HBox hBox = new HBox();
        hBox.getChildren().addAll(new Label("Filtre:"), salleComboBox, personnelComboBox);
        this.getChildren().add(hBox);
        this.getChildren().add(new ScrollPane(gridPane));
    }

    void miseEnFormeGrid(){
        int rowCount = 24*4;
        int columnCount = 7;
        RowConstraints rc = new RowConstraints();
        rc.setPercentHeight(99d / rowCount);
        for (int i = 0; i < rowCount; i++) {
            gridPane.getRowConstraints().add(rc);
        }
        ColumnConstraints cc = new ColumnConstraints();
        cc.setPercentWidth(97d / columnCount);
        for (int i = 0; i < columnCount; i++) {
            gridPane.getColumnConstraints().add(cc);
        }
        addTitreJoursDeLaSemaine();
    }

    void addTitreJoursDeLaSemaine(){
        String[] joursDeLaSemaine = {"Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"};
        for(int x=0;x<7;x++){
            String jourDeLaSemaine = joursDeLaSemaine[x];
            gridPane.add(new Label(jourDeLaSemaine),x,0);
        }
    }

    void refresh(){
        gridPane.getChildren().clear();
        addTitreJoursDeLaSemaine();
        addRDV();
    }

    void addRDV(){
        this.rdvs = BaseDeDonnee.getRDVs(salleComboBox.getValue(),personnelComboBox.getValue());
        for(RDV rdv:rdvs){
            ZonedDateTime zdtDebut=rdv.debut.atZone(ZoneOffset.UTC);
            ZonedDateTime zdtFin=rdv.fin.atZone(ZoneOffset.UTC);
            int x = zdtDebut.getDayOfWeek().getValue()-1;
            int heuresDebut = zdtDebut.getHour();
            int minutesDebut = zdtDebut.getMinute();
            int heuresFin = zdtFin.getHour();
            int minutesFin = zdtFin.getMinute();
            int y = heuresDebut*4+minutesDebut/15;
            int rowspan = (int) rdv.debut.until(rdv.fin, java.time.temporal.ChronoUnit.MINUTES);
            rowspan /= 15;

            String affichageHeureDebut = String.format("%02dh%02d",heuresDebut,minutesDebut);
            String affichageHeureFin = String.format("%02dh%02d",heuresFin,minutesFin);
            String affichageHoraire = affichageHeureDebut+" - "+affichageHeureFin;
            Button button = new Button(affichageHoraire+": "+rdv.nom);
            button.setMaxSize(Double.MAX_VALUE,Double.MAX_VALUE);
            RDVController rdvController = vueRDV.getRDVController();
            button.setOnAction(event-> {rdvController.updateRDV(rdv);mainScene.showVueRDV();});
            gridPane.add(button,x,y+1,1,rowspan);
        }
    }

    public void removeRDV(RDV rdv){
        rdvs.remove(rdv);
        gridPane.getChildren().clear();
        this.addTitreJoursDeLaSemaine();
        this.addRDV();
    }

    private void updateSalle(){
        Salle[] salles = BaseDeDonnee.getSalles();
        salleComboBox.setOnAction(null);
        salleComboBox.getItems().clear();
        salleComboBox.getItems().addAll(salles);
        salleComboBox.getItems().add(null);
        salleComboBox.getSelectionModel().select(null);
        salleComboBox.setOnAction(event->refresh());
    }

    private void updatePersonnel(){
        Personnel[] personnels = BaseDeDonnee.getPersonnels();
        personnelComboBox.setOnAction(null);
        personnelComboBox.getItems().clear();
        personnelComboBox.getItems().addAll(personnels);
        personnelComboBox.getItems().add(null);
        personnelComboBox.getSelectionModel().select(null);
        personnelComboBox.setOnAction(event->refresh());
    }
}