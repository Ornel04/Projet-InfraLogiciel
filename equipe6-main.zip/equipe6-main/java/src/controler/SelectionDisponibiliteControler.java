package src.controler;

import src.model.BaseDeDonnee;
import src.model.ICare;
import src.vue.VueSelectionDisponibilite;
import java.time.Instant;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

public class SelectionDisponibiliteControler {

    private ICare iCare;
    VueSelectionDisponibilite vueSelectionDisponibilite;

    public SelectionDisponibiliteControler(VueSelectionDisponibilite vueSelectionDisponibilite, ICare iCare){
        this.vueSelectionDisponibilite = vueSelectionDisponibilite;
        this.iCare = iCare;
    }

    public void ajoutDisponibilite(){
        Instant debut = Instant.from(vueSelectionDisponibilite.getDebutDisponibilite().atStartOfDay(ZoneId.systemDefault()));
        int hour = vueSelectionDisponibilite.getHeureDebutDisponibilite();
        int minute = vueSelectionDisponibilite.getMinuteDebutDisponibilite();
        debut = debut.plus(hour, ChronoUnit.HOURS);
        debut = debut.plus(minute, ChronoUnit.MINUTES);
        Instant fin = Instant.from(vueSelectionDisponibilite.getFinDisponibilite().atStartOfDay(ZoneId.systemDefault()));
        hour = vueSelectionDisponibilite.getHeureFinDisponibilite();
        minute = vueSelectionDisponibilite.getMinuteFinDisponibilite();
        fin = fin.plus(hour, ChronoUnit.HOURS);
        fin = fin.plus(minute, ChronoUnit.MINUTES);
        BaseDeDonnee.addDisponibilite(iCare.getComptePersonnel().getId(), debut, fin);
    }
}
