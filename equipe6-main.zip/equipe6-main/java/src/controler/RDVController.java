package src.controler;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import src.model.BaseDeDonnee;
import src.model.Planning;
import src.model.RDV;
import src.model.Salle;
import src.vue.VueRDV;

import java.util.Optional;

public class RDVController {
    private VueRDV vueRDV;
    private RDV rdv;
    private Planning planning;

    public RDVController(VueRDV vueRDV) {
        vueRDV.setRDVController(this);
        this.vueRDV = vueRDV;
        this.rdv = vueRDV.getRDV();
    }

    public void updateRDV(RDV rdv) {
        this.rdv = rdv;
        vueRDV.updateRDV(rdv);
    }

    public void updateSalle() {
        Alert dialogC = new Alert(Alert.AlertType.CONFIRMATION);
        dialogC.setTitle("Confirmation");
        dialogC.setHeaderText(null);
        dialogC.setContentText("Voulez-vous confirmer ?");
        Optional<ButtonType> answer = dialogC.showAndWait();
        vueRDV.getSalleComboBox().setOnAction(null);
        if(answer.get() == ButtonType.OK) {
            rdv.setSalle(vueRDV.getSalleComboBox().getSelectionModel().getSelectedItem());
        }else{
            vueRDV.getSalleComboBox().getSelectionModel().select(rdv.getSalle());
        }
        vueRDV.getSalleComboBox().setOnAction(event->this.updateSalle());
        BaseDeDonnee.updateRDV(rdv);
    }

    public void updatePersonnel(){
        Alert dialogC = new Alert(Alert.AlertType.CONFIRMATION);
        dialogC.setTitle("Confirmation");
        dialogC.setHeaderText(null);
        dialogC.setContentText("Voulez-vous confirmer ?");
        Optional<ButtonType> answer = dialogC.showAndWait();
        vueRDV.getPersonnelComboBox().setOnAction(null);
        if(answer.get() == ButtonType.OK) {
            rdv.setPersonnel(vueRDV.getPersonnelComboBox().getSelectionModel().getSelectedItem());
        }else{
            vueRDV.getPersonnelComboBox().getSelectionModel().select(rdv.getPersonnel());
        }
        vueRDV.getPersonnelComboBox().setOnAction(event->this.updatePersonnel());
        BaseDeDonnee.updateRDV(rdv);
    }

    public void updateValidation(){
        Alert dialogC = new Alert(Alert.AlertType.CONFIRMATION);
        dialogC.setTitle("Confirmation");
        dialogC.setHeaderText(null);
        dialogC.setContentText("Voulez-vous confirmer ?");
        Optional<ButtonType> answer = dialogC.showAndWait();
        vueRDV.getIsValideComboBox().setOnAction(null);
        if(answer.get() == ButtonType.OK) {
            switch(vueRDV.getIsValideComboBox().getSelectionModel().getSelectedItem()){
                case "En attente":
                    rdv.setValide(false);
                    BaseDeDonnee.updateRDV(rdv);
                    break;
                case "Valide":
                    rdv.setValide(true);
                    BaseDeDonnee.updateRDV(rdv);
                    break;
                case "Annuler":
                    vueRDV.updateRDV(null);
                    planning.removeRDV(rdv);
                    BaseDeDonnee.deleteRDV(rdv);
                    return;
            }
        }else{
            if(!rdv.isValide()){
                vueRDV.getIsValideComboBox().getSelectionModel().select("En attente de confirmation");
            }else{
                vueRDV.getIsValideComboBox().getSelectionModel().select("Valide");
            }
        }
        vueRDV.getIsValideComboBox().setOnAction(event->this.updateValidation());
    }

    public void setPlanning(Planning planning){
        this.planning = planning;
    }
}